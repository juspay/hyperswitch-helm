# hyperswitch-ucs

![Version: 0.1.11](https://img.shields.io/badge/Version-0.1.11-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: v0.6.0](https://img.shields.io/badge/AppVersion-v0.6.0-informational?style=flat-square)

A Helm chart for Hyperswitch UCS Service

## TL;DR

```bash
helm repo add hyperswitch https://juspay.github.io/hyperswitch-helm/
helm install hyperswitch-ucs hyperswitch/hyperswitch-ucs
```

## Introduction

This chart deploys the Hyperswitch UCS (Unified Connector Service) on a Kubernetes cluster using the Helm package manager.

## Prerequisites

- Kubernetes 1.19+
- Helm 3.2.0+

## Installing the Chart

To install the chart with the release name `hyperswitch-ucs`:

```bash
helm install hyperswitch-ucs ./charts/incubator/hyperswitch-ucs -n hyperswitch --create-namespace
```

## Uninstalling the Chart

To uninstall/delete the `hyperswitch-ucs` deployment:

```bash
helm uninstall hyperswitch-ucs -n hyperswitch
```

## Configuration

The following table lists the configurable parameters of the hyperswitch-ucs chart and their default values.

## Values

### Connector Service

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| affinity | object | `{}` | Affinity for pod assignment |
| autoscaling | object | `{"enabled":false,"maxReplicas":100,"minReplicas":1,"targetCPUUtilizationPercentage":80}` | Autoscaling configuration |
| autoscaling.enabled | bool | `false` | Enable autoscaling |
| autoscaling.maxReplicas | int | `100` | Maximum number of replicas |
| autoscaling.minReplicas | int | `1` | Minimum number of replicas |
| autoscaling.targetCPUUtilizationPercentage | int | `80` | Target CPU utilization percentage |
| fullnameOverride | string | `""` | Override the full name of the chart |
| image | object | `{"imageRegistry":"docker.io","pullPolicy":"IfNotPresent","repository":"juspaydotin/hyperswitch-prism","tag":"v0.6.0"}` | Container image configuration |
| image.imageRegistry | string | `"docker.io"` | Docker image registry |
| image.pullPolicy | string | `"IfNotPresent"` | Image pull policy |
| image.repository | string | `"juspaydotin/hyperswitch-prism"` | Docker image repository |
| image.tag | string | `"v0.6.0"` | Image tag to use |
| imagePullSecrets | list | `[]` | Image pull secrets for private registries |
| ingress | object | `{"annotations":{},"className":"","enabled":false,"hosts":[{"host":"hyperswitch-ucs.local","paths":[{"path":"/","pathType":"ImplementationSpecific"}]}],"tls":[]}` | Ingress configuration |
| ingress.annotations | object | `{}` | Additional annotations for the Ingress resource |
| ingress.className | string | `""` | IngressClass that will be used to implement the Ingress |
| ingress.enabled | bool | `false` | Enable ingress controller resource |
| ingress.hosts | list | `[{"host":"hyperswitch-ucs.local","paths":[{"path":"/","pathType":"ImplementationSpecific"}]}]` | An array with hostname(s) to be covered with the ingress record |
| ingress.tls | list | `[]` | TLS configuration for hostname(s) to be covered with this ingress record |
| livenessProbe | object | `{"failureThreshold":3,"grpc":{"port":8000,"service":"grpc.health.v1.Health"},"initialDelaySeconds":90,"periodSeconds":30,"successThreshold":1,"timeoutSeconds":10}` | Liveness probe configuration |
| livenessProbe.failureThreshold | int | `3` | Number of failures before pod is restarted |
| livenessProbe.grpc | object | `{"port":8000,"service":"grpc.health.v1.Health"}` | gRPC health check configuration |
| livenessProbe.grpc.port | int | `8000` | gRPC port for health check |
| livenessProbe.grpc.service | string | `"grpc.health.v1.Health"` | gRPC service name for health check |
| livenessProbe.initialDelaySeconds | int | `90` | Initial delay before probe starts |
| livenessProbe.periodSeconds | int | `30` | How often to perform the probe |
| livenessProbe.successThreshold | int | `1` | Minimum consecutive successes for the probe to be considered successful |
| livenessProbe.timeoutSeconds | int | `10` | Number of seconds after which the probe times out |
| nameOverride | string | `""` | Override the name of the chart |
| nodeSelector | object | `{}` | Node labels for pod assignment |
| podAnnotations | object | `{}` | Annotations to add to the pod |
| podSecurityContext | object | `{}` | Pod security context |
| readinessProbe | object | `{"failureThreshold":5,"grpc":{"port":8000,"service":"grpc.health.v1.Health"},"initialDelaySeconds":30,"periodSeconds":30,"successThreshold":1,"timeoutSeconds":5}` | Readiness probe configuration |
| readinessProbe.failureThreshold | int | `5` | Number of failures before pod is marked unready |
| readinessProbe.grpc | object | `{"port":8000,"service":"grpc.health.v1.Health"}` | gRPC health check configuration |
| readinessProbe.grpc.port | int | `8000` | gRPC port for health check |
| readinessProbe.grpc.service | string | `"grpc.health.v1.Health"` | gRPC service name for health check |
| readinessProbe.initialDelaySeconds | int | `30` | Initial delay before probe starts |
| readinessProbe.periodSeconds | int | `30` | How often to perform the probe |
| readinessProbe.successThreshold | int | `1` | Minimum consecutive successes for the probe to be considered successful |
| readinessProbe.timeoutSeconds | int | `5` | Number of seconds after which the probe times out |
| replicaCount | int | `1` | Number of replicas for the UCS deployment |
| resources | object | `{"limits":{"cpu":"1000m","memory":"1000Mi"},"requests":{"cpu":"400m","memory":"400Mi"}}` | Resource limits and requests for the UCS containers |
| resources.limits | object | `{"cpu":"1000m","memory":"1000Mi"}` | Resource limits |
| resources.limits.cpu | string | `"1000m"` | CPU limit |
| resources.limits.memory | string | `"1000Mi"` | Memory limit |
| resources.requests | object | `{"cpu":"400m","memory":"400Mi"}` | Resource requests |
| resources.requests.cpu | string | `"400m"` | CPU request |
| resources.requests.memory | string | `"400Mi"` | Memory request |
| securityContext | object | `{}` | Container security context |
| service | object | `{"grpc":{"port":8000,"targetPort":8000},"metrics":{"port":8080,"targetPort":8080},"type":"ClusterIP"}` | Service configuration |
| service.grpc | object | `{"port":8000,"targetPort":8000}` | gRPC service configuration |
| service.grpc.port | int | `8000` | gRPC service port |
| service.grpc.targetPort | int | `8000` | gRPC container port |
| service.metrics | object | `{"port":8080,"targetPort":8080}` | Metrics service configuration |
| service.metrics.port | int | `8080` | Metrics service port |
| service.metrics.targetPort | int | `8080` | Metrics container port |
| service.type | string | `"ClusterIP"` | Service type |
| serviceAccount | object | `{"annotations":{},"create":true,"name":""}` | Service account configuration |
| serviceAccount.annotations | object | `{}` | Annotations to add to the service account |
| serviceAccount.create | bool | `true` | Specifies whether a service account should be created |
| serviceAccount.name | string | `""` | The name of the service account to use. If not set and create is true, a name is generated using the fullname template |
| serviceMonitor | object | `{"enabled":false,"interval":"","labels":{},"metricRelabelings":[],"namespace":"","path":"/metrics","portName":"metrics","relabelings":[],"scheme":"http","scrapeTimeout":"","targetLabels":[]}` | ServiceMonitor configuration for Victoria Metrics / Prometheus scraping |
| serviceMonitor.enabled | bool | `false` | Enable ServiceMonitor resource |
| serviceMonitor.interval | string | `""` | Scrape interval |
| serviceMonitor.labels | object | `{}` | Additional labels for the ServiceMonitor |
| serviceMonitor.metricRelabelings | list | `[]` | Metric relabeling rules |
| serviceMonitor.namespace | string | `""` | Namespace to deploy ServiceMonitor (defaults to release namespace) |
| serviceMonitor.path | string | `"/metrics"` | Metrics path |
| serviceMonitor.portName | string | `"metrics"` | Port name to scrape (must match service port name) |
| serviceMonitor.relabelings | list | `[]` | Relabeling rules |
| serviceMonitor.scheme | string | `"http"` | HTTP scheme |
| serviceMonitor.scrapeTimeout | string | `""` | Scrape timeout |
| serviceMonitor.targetLabels | list | `[]` | Target labels |
| tolerations | list | `[]` | Tolerations for pod assignment |

### Connector Service Configurations

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| config.log.console.enabled | bool | `true` | Enable console logging |
| config.log.console.level | string | `"DEBUG"` | Log level (DEBUG, INFO, WARN, ERROR) |
| config.log.console.log_format | string | `"json"` | Log format (json, text) |
| config.metrics.host | string | `"0.0.0.0"` | Metrics server host address |
| config.metrics.port | int | `8080` | Metrics server port |
| config.proxy.http_url | string | `nil` | Optional HTTP proxy URL; leave null for direct connections |
| config.proxy.https_url | string | `nil` | Optional HTTPS proxy URL; leave null for direct connections |
| config.server.host | string | `"0.0.0.0"` | Server host address |
| config.server.port | int | `8000` | Server port |
| config.server.type | string | `"grpc"` | Server type |

### Secrets

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| disableInternalSecrets | bool | `false` | Disable the chart-managed Secret built from `_secret` values under `config` (set true when every secret arrives through `_secretRef` or the External Secrets Operator) |
| externalSecretsOperator.enabled | bool | `false` | Enable External Secrets Operator resources |
| externalSecretsOperator.externalSecrets.secrets | list | `[]` | ExternalSecrets to create; each entry takes `name`, `targetName`, `refreshInterval`, `creationPolicy`, an optional `template`, and `data` (single keys) or `dataFrom` (whole secret) |
| externalSecretsOperator.secretStore.create | bool | `true` | Create the SecretStore (set false to reference one that already exists) |
| externalSecretsOperator.secretStore.kind | string | `"SecretStore"` | Kind the ExternalSecrets reference: `SecretStore` (namespaced, created by this chart) or `ClusterSecretStore` (platform-owned, referenced only) |
| externalSecretsOperator.secretStore.name | string | `"hyperswitch-ucs-secret-store"` | Name of the SecretStore |
| externalSecretsOperator.secretStore.provider | object | `{"aws":{"auth":{"jwt":{"serviceAccountRef":{"name":"hyperswitch-ucs"}}},"region":"us-west-2","service":"SecretsManager"}}` | Provider configuration in External Secrets Operator format (see https://external-secrets.io/latest/) |
| externalSecretsOperator.serviceAccount.annotations | object | `{}` | Annotations for the service account (e.g. the IRSA role ARN) |
| externalSecretsOperator.serviceAccount.create | bool | `false` | Create a dedicated service account for the SecretStore (leave false to authenticate as the application's service account) |
| externalSecretsOperator.serviceAccount.extraLabels | object | `{}` | Extra labels for the service account |
| externalSecretsOperator.serviceAccount.name | string | `""` | Name of the service account (default: hyperswitch-ucs-eso-sa) |

### Istio

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| istio | object | `{"destinationRule":{"trafficPolicy":{}},"enabled":false,"virtualService":{"create":true,"gateways":[],"hosts":[],"http":[{"match":[],"name":"primary","retries":{},"timeout":"50s","weight":100}],"tcp":[]}}` | Istio configuration |

### Other Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| argoRollouts | object | `{"canary":{"steps":[],"trafficRouting":{"headerRouting":{"enabled":false,"match":[],"routeName":"header-canary"},"istio":{"destinationRule":{"canarySubsetName":"canary","stableSubsetName":"stable"},"enabled":false,"virtualService":{"routeNames":["primary"]}}}},"enabled":false,"revisionHistoryLimit":10}` | Argo Rollouts configuration |
| argoRollouts.canary.steps | list | `[]` | Canary deployment steps (see Argo Rollouts docs) |
| argoRollouts.canary.trafficRouting.headerRouting | object | `{"enabled":false,"match":[],"routeName":"header-canary"}` | Header-based routing configuration |
| argoRollouts.canary.trafficRouting.headerRouting.enabled | bool | `false` | Enable header-based canary routing |
| argoRollouts.canary.trafficRouting.headerRouting.match | list | `[]` | Header match conditions |
| argoRollouts.canary.trafficRouting.headerRouting.routeName | string | `"header-canary"` | Route name for header-based routing |
| argoRollouts.canary.trafficRouting.istio.destinationRule.canarySubsetName | string | `"canary"` | Name of the canary subset in Istio DestinationRule |
| argoRollouts.canary.trafficRouting.istio.destinationRule.stableSubsetName | string | `"stable"` | Name of the stable subset in Istio DestinationRule |
| argoRollouts.canary.trafficRouting.istio.enabled | bool | `false` | Enable Istio traffic routing for canary |
| argoRollouts.canary.trafficRouting.istio.virtualService | object | `{"routeNames":["primary"]}` | VirtualService configuration for Argo Rollouts |
| argoRollouts.canary.trafficRouting.istio.virtualService.routeNames | list | `["primary"]` | Route names to be managed by Argo Rollouts |
| argoRollouts.enabled | bool | `false` | Enable Argo Rollouts instead of standard Deployment |
| argoRollouts.revisionHistoryLimit | int | `10` | Number of old ReplicaSets to retain for rollback |
| config.server.run_env | string | `"sandbox"` | Runtime environment (production, sandbox) |
| env | list | `[]` |  |
| global.imageRegistry | string | `nil` |  |
| istio.destinationRule | object | `{"trafficPolicy":{}}` | DestinationRule configuration |
| istio.destinationRule.trafficPolicy | object | `{}` | Traffic policy configuration - rendered directly as YAML |
| istio.enabled | bool | `false` | Enable Istio resources |
| istio.virtualService | object | `{"create":true,"gateways":[],"hosts":[],"http":[{"match":[],"name":"primary","retries":{},"timeout":"50s","weight":100}],"tcp":[]}` | VirtualService configuration |
| istio.virtualService.create | bool | `true` | Create VirtualService |
| istio.virtualService.gateways | list | `[]` | Gateways for the VirtualService |
| istio.virtualService.hosts | list | `[]` | Hosts for the VirtualService |
| istio.virtualService.http | list | `[{"match":[],"name":"primary","retries":{},"timeout":"50s","weight":100}]` | HTTP routing rules (ordered list) Note: Rules are processed in the order they appear in this list. |
| istio.virtualService.tcp | list | `[]` | TCP routing rules for gRPC |
| strategy | object | `{}` |  |

### Example Configuration

#### Running without proxy (for local development)

```yaml
# values-local.yaml
env:
  - name: CS__PROXY__HTTPS_URL
    value: ""
  - name: CS__PROXY__HTTP_URL
    value: ""
  - name: CS__PROXY__BYPASS_PROXY_URLS
    value: ""
```

```bash
helm install hyperswitch-ucs ./charts/incubator/hyperswitch-ucs -f values-local.yaml -n hyperswitch
```

#### Running with custom resource limits

```yaml
# values-production.yaml
replicaCount: 3

resources:
  limits:
    cpu: 2000m
    memory: 2Gi
  requests:
    cpu: 1000m
    memory: 1Gi

autoscaling:
  enabled: true
  minReplicas: 3
  maxReplicas: 10
  targetCPUUtilizationPercentage: 70
```

#### Delivering secrets

Every key under `config` becomes a `CS__*` environment variable. A key can be written as a
secret or a reference instead of a plain value, using the same conventions as the
hyperswitch-app chart; such keys never land in the ConfigMap.

```yaml
config:
  superposition:
    enabled: true
    endpoint: http://superposition.superposition.svc.cluster.local:80
    org_id: hyperswitch
    workspace_id: ucs
    # chart-managed Secret <release>-hyperswitch-ucs-secrets, key CS__SUPERPOSITION__TOKEN
    token:
      _secret: "sp_…"
```

```yaml
config:
  superposition:
    # env CS__SUPERPOSITION__TOKEN from an existing Secret; `optional: true` lets the pod
    # start (and fall back to the baked file) before the Secret is materialised
    token:
      _secretRef:
        name: hyperswitch-ucs-secrets
        key: CS__SUPERPOSITION__TOKEN
        optional: true

# Materialise that Secret from AWS Secrets Manager with the External Secrets Operator.
# The SecretStore authenticates as the application's service account, which carries the
# IRSA role with read access to the secret.
disableInternalSecrets: true
externalSecretsOperator:
  enabled: true
  secretStore:
    provider:
      aws:
        service: SecretsManager
        region: ap-south-1
        auth:
          jwt:
            serviceAccountRef:
              name: hyperswitch-ucs
  externalSecrets:
    secrets:
      - name: hyperswitch-ucs-secrets
        targetName: hyperswitch-ucs-secrets
        dataFrom:
          - extract:
              key: sandbox/hyperswitch-ucs
```

To reference a platform-owned `ClusterSecretStore` instead of creating a namespaced
`SecretStore`, set `externalSecretsOperator.secretStore.kind: ClusterSecretStore`,
`create: false`, and `name` to the store's name.

## Service Details

The chart deploys two services:
- **gRPC Service** (port 8000): Main gRPC service endpoint
- **Metrics Service** (port 8080): Prometheus metrics endpoint

### Health Checks

The deployment includes both liveness and readiness probes using gRPC health checks:
- Liveness probe: Ensures the container is running
- Readiness probe: Ensures the service is ready to accept traffic

### Monitoring

Prometheus metrics are exposed on port 8080 at `/metrics` endpoint. Metrics include:
- `GRPC_SERVER_REQUESTS_TOTAL`: Total number of gRPC requests
- `GRPC_SERVER_REQUESTS_SUCCESSFUL`: Number of successful requests
- `GRPC_SERVER_REQUEST_LATENCY`: Request latency histogram

## Troubleshooting

### Check pod status
```bash
kubectl get pods -l app.kubernetes.io/name=hyperswitch-ucs -n hyperswitch
kubectl describe pod -l app.kubernetes.io/name=hyperswitch-ucs -n hyperswitch
```

### Check logs
```bash
kubectl logs -l app.kubernetes.io/name=hyperswitch-ucs -n hyperswitch
```

### Test metrics endpoint
```bash
kubectl port-forward svc/hyperswitch-ucs 8080:8080 -n hyperswitch
curl http://localhost:8080/metrics
```

### Test gRPC health endpoint
```bash
kubectl port-forward svc/hyperswitch-ucs 8000:8000 -n hyperswitch
grpcurl -plaintext localhost:8000 grpc.health.v1.Health/Check
```

